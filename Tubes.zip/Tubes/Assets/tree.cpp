#include "tree.h"
#include "shapes.h"

void drawTree(float px, float pz, GLuint texBark, GLuint texLeaf) {
    glPushMatrix();
    glTranslatef(px, 0, pz);

    glEnable(GL_TEXTURE_2D);

    // batang

    if (texBark != 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texBark);
    } else {
        glDisable(GL_TEXTURE_2D);
    }
    glBindTexture(GL_TEXTURE_2D, texBark);
    glColor3f(1,1,1);

    drawBoxTextured(0.2f, 1.2f, 0.2f, 1.0f, 3.0f);

    // daun
    glTranslatef(0, 1.0f, 0);

    if (texLeaf != 0) {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texLeaf);
    } else {
        glDisable(GL_TEXTURE_2D);
    }

    glBindTexture(GL_TEXTURE_2D, texLeaf);

    drawBoxTextured(1.0f, 1.4f, 1.0f, 1.0f, 1.0f);

    glDisable(GL_TEXTURE_2D);

    glPopMatrix();
}